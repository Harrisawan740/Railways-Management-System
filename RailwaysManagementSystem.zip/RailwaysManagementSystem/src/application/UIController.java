package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class UIController {

    @FXML
    void MainPage(ActionEvent event) {
		try {
			
			Parent root= FXMLLoader.load(getClass().getClassLoader().getResource("MainPage.fxml"));
			Scene scene = new Scene(root);
		   Stage primaryStage =new Stage();
			primaryStage.setScene(scene);
			primaryStage.setResizable(true);
			primaryStage.show();
		} catch(Exception e) {
			
			e.printStackTrace(); 
		} 
		
    }

}
