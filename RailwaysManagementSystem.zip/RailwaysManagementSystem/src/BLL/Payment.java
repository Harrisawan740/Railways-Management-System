package BLL;

public class Payment {

	int reservation_id;
	int amount;
	Passenger p;
	Reciept r;
	PaymentHandler P_handler;
	
	public int getReservation_id() {
		return reservation_id;
	}
	public void setReservation_id(int reservation_id) {
		this.reservation_id = reservation_id;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Passenger getP() {
		return p;
	}
	public void setP(Passenger p) {
		this.p = p;
	}
	
	public boolean cancelPayment() {
		
		return true;
		
	}
	public Reciept makePayment() {
		
		return r;
	}
	public boolean checkOverdue() {
		
		return true;
		
	}
	public void payment_type() {
		
		
		
	}
	
	
	
}
