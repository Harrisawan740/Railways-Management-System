package BLL;

public class Reservation {

	
	int id;
	int Number_of_seats;
	String destination;
	String payment_type;
	Ticket ticket;
	public Ticket getTicket() {
		return ticket;
	}
	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNumber_of_seats() {
		return Number_of_seats;
	}
	public void setNumber_of_seats(int number_of_seats) {
		Number_of_seats = number_of_seats;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getPayment_type() {
		return payment_type;
	}
	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}
	
	
	
	
	
	
}
