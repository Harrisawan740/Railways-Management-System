package BLL;

import java.sql.SQLException;

import ServicesLayer.Data_base;

public class main {

	public static void main(String[] args) throws SQLException {
		// TOD00O Auto-generated method stub
      Data_base db=new Data_base();
      db.getdata();
	}

}
