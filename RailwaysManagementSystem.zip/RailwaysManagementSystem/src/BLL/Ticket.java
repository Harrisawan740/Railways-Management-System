package BLL;

public class Ticket {

	int id;
	
	
	
}
