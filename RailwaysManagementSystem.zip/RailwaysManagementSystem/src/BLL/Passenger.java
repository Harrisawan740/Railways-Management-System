package BLL;

import java.util.ArrayList;

public class Passenger {

	String name;
	
	int CNIC;
	
	String gender;
	
	int age;
	
	String address;
	
	ArrayList <Reservation> reservations;
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getCNIC() {
		return CNIC;
	}


	public void setCNIC(int cNIC) {
		CNIC = cNIC;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public ArrayList<Reservation> getReservations() {
		return reservations;
	}


	public void setReservations(ArrayList<Reservation> reservations) {
		this.reservations = reservations;
	}


	
	
	
	
	
	
}
