package BLL;

public class Reciept {

	
	
}
