package BLL;

import java.util.ArrayList;

public class ReservationCatalog {

	ArrayList <Reservation> reservations;
	
	public ReservationCatalog () {
		
	}
	
}
