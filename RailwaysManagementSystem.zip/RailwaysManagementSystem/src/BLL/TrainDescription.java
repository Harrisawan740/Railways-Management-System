package BLL;

public class TrainDescription {

	String make;
	
	String number_of_seats;
	
	String model;

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getNumber_of_seats() {
		return number_of_seats;
	}

	public void setNumber_of_seats(String number_of_seats) {
		this.number_of_seats = number_of_seats;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	
	
	
	
	
}
