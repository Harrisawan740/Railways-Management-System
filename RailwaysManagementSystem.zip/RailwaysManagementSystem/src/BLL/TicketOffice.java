package BLL;

import java.util.ArrayList;

public class TicketOffice {
	
	ArrayList <Passenger> passengers;
	
	ArrayList <Feedback> feedback;
	
	ArrayList <FAQ> faq;
	
	RailwayStation railwaystation;
	
	ArrayList<Train> trains;
	
	ArrayList<Reciept> reciept;
	
	ArrayList <Schedule> schedule;
	
	ArrayList <ReservationCatalog> RCatalog;
	
	
	ArrayList <TrainDescription> traindescription;
	
	
	
	
}
