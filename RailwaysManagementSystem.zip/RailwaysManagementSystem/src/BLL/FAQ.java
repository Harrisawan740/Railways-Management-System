package BLL;

public class FAQ {

}
