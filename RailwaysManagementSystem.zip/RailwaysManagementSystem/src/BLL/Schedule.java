package BLL;

public class Schedule {

	
	
}
