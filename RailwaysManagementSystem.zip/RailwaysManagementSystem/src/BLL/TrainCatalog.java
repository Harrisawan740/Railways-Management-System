package BLL;

import java.util.ArrayList;

public class TrainCatalog {

	ArrayList <Train > trains;

	public ArrayList<Train> getTrains() {
		return trains;
	}

	public void setTrains(ArrayList<Train> trains) {
		this.trains = trains;
	}
	
	
}
