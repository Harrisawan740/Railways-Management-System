package BLL;

public class PaymentHandler {

	
	String type;
	public PaymentHandler() {
		
		
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	
	
	
}
