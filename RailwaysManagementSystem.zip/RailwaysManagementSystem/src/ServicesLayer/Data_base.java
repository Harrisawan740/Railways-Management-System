package ServicesLayer;
import java.sql.*;

public class Data_base {
	
	private Connection con;
	
	public Data_base(){
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully");
			
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:HARRIS","scott","harris701");
			
			System.out.println("Connection Established");
		}
		catch(Exception e)
		{
			System.out.println("Database Connection Failed!");
		}
	}
	
	
	public int getdata() throws SQLException {
		
		Statement smt = con.createStatement();
		ResultSet rs = smt.executeQuery("SELECT * FROM EMPLOYEES");
		while(rs.next())
		{
			System.out.println(rs.getString(2));
		}
		return 0;
	
	}
}
